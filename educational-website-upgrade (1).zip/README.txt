# LearnSphere educational website

This folder contains a responsive Black & Gold educational website template.

## Files
- index.html — page content and sections
- style.css — visual design and responsive layout
- script.js — mobile menu, reveal animations, year and contact form

## Before publishing
1. Open script.js.
2. Replace YOUR_EMAIL@example.com with the email address where you want to receive enquiries.
3. Replace the sample LearnSphere name, sample descriptions, skill levels and project examples with your real information.
4. Open index.html in a browser to preview the website.

## Contact form note
GitHub Pages only hosts static files. This template uses a mailto form: it opens the visitor's email application with the message filled in. It does not send or store messages directly on the website. For a form that submits directly online, connect a form service such as Formspree or another backend.

## Publish to the existing GitHub Pages site
1. Open your GitHub repository: https://github.com/malickaman086-png/my-first-website
2. Open the repository's Code tab.
3. Upload/replace index.html, style.css and script.js in the repository root (same level).
4. Commit the changes to the main branch.
5. Wait for GitHub Pages deployment to finish.
6. Visit https://malickaman086-png.github.io/my-first-website/

Keep the filenames exactly as shown. The index.html file must be in the repository root.
